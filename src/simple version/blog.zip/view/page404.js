import React from 'react';

function NotFoundPage(){
    return <div>Could not find the page</div>
}

export default NotFoundPage;