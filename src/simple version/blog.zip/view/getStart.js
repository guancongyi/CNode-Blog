import React from 'react';

function GetStartPage(){
    return <div>get start</div>
}

export default GetStartPage;