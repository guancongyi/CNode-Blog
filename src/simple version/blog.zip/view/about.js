import React from 'react';

function AboutPage(){
    return <div>about</div>
}

export default AboutPage;